@echo off
cd /d "%~dp0"
node finish.mjs matchlock matchlock_short_9x16.mp4
pause
