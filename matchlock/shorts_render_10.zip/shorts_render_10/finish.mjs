// Wysyłka gotowego MP4 z PC na GitHuba (Gromiasty/shorts-media). Użycie: node finish.mjs <folder_filmu> <plik.mp4>
import fs from 'fs'; import path from 'path'; import { execFileSync } from 'child_process'; import { fileURLToPath } from 'url';
const D = path.dirname(fileURLToPath(import.meta.url)), [FOLDER, NAME] = process.argv.slice(2);
const run = (cmd, a, cwd) => execFileSync(cmd, a, { cwd: cwd || D, stdio: 'inherit' });
const R = path.join(D, 'repo');
if (!fs.existsSync(R)) { run('git', ['clone', '--depth', '1', '--filter=blob:none', '--sparse', 'https://github.com/Gromiasty/shorts-media', 'repo']); run('git', ['sparse-checkout', 'set', FOLDER], R); }
else { run('git', ['sparse-checkout', 'add', FOLDER], R); run('git', ['pull', '--ff-only'], R); }
fs.mkdirSync(path.join(R, FOLDER), { recursive: true }); fs.copyFileSync(path.join(D, NAME), path.join(R, FOLDER, NAME));
run('git', ['add', FOLDER + '/' + NAME], R); run('git', ['commit', '-m', `${FOLDER}: MP4 9:16 (GPU render)`], R); run('git', ['push', 'origin', 'HEAD:main'], R);
console.log('GOTOWE. Napisz Claude\'owi, że wysłane.');
