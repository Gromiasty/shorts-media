// Lokalny render Shorta na GPU (Windows, Chrome). Uruchom: start.bat (albo: npm install && node render_local.mjs)
import fs from 'fs'; import path from 'path'; import { spawn, execFileSync } from 'child_process'; import { pathToFileURL, fileURLToPath } from 'url';
import { chromium } from 'playwright-core'; import ffmpeg from 'ffmpeg-static';
const D = path.dirname(fileURLToPath(import.meta.url)); const OUT = path.join(D, 'out'); fs.mkdirSync(OUT, { recursive: true });
const FPS = 30, WK = +(process.argv[2] || 4), NAME = 'matchlock_short_9x16.mp4';
const chromes = [process.env.CHROME, 'C:/Program Files/Google/Chrome/Application/chrome.exe', 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
  path.join(process.env.LOCALAPPDATA || '', 'Google/Chrome/Application/chrome.exe')].filter(p => p && fs.existsSync(p));
if (!chromes.length) { console.error('Nie znalazłem Google Chrome. Zainstaluj Chrome albo ustaw zmienną CHROME na ścieżkę do chrome.exe.'); process.exit(1); }
const ARGS = ['--ignore-gpu-blocklist', '--enable-gpu-rasterization', '--use-angle=d3d11', '--force-color-profile=srgb', '--allow-file-access-from-files', '--disable-background-timer-throttling', '--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows'];
async function open() {
  const b = await chromium.launch({ executablePath: chromes[0], headless: false, args: ARGS });
  const p = await b.newPage({ viewport: { width: 1080, height: 1920 }, deviceScaleFactor: 1 });
  p.on('pageerror', e => { console.error('[błąd strony]', e.message); process.exit(1); });
  await p.goto(pathToFileURL(path.join(D, 'render.html')).href + '?render');
  await p.waitForFunction(() => window.READY === true, null, { timeout: 180000 });
  return { b, p };
}
const t0 = Date.now();
const probe = await open();
const info = await probe.p.evaluate(() => { const gl = window.RR.getContext('webgl2') || window.RR.getContext('webgl'); const e = gl && gl.getExtension('WEBGL_debug_renderer_info');
  return { dur: window.DUR, gpu: e ? gl.getParameter(e.UNMASKED_RENDERER_WEBGL) : '?' }; });
await probe.b.close();
console.log('GPU:', info.gpu); if (/swiftshader|llvmpipe|software/i.test(info.gpu)) console.warn('UWAGA: Chrome nie używa karty graficznej, render będzie wolny.');
const N = Math.round(info.dur * FPS), per = Math.ceil(N / WK); let done = 0;
await Promise.all([...Array(WK)].map(async (_, w) => {
  const a = w * per, b = Math.min(N, a + per); if (a >= b) return; const seg = path.join(OUT, `seg_${w}.mp4`);
  const { b: br, p } = await open();
  const ff = spawn(ffmpeg, ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(FPS), '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '12', '-pix_fmt', 'yuv420p', seg], { stdio: ['pipe', 'inherit', 'inherit'] });
  const closed = new Promise(r => ff.on('close', r));
  for (let f = a; f < b; f++) {
    await p.evaluate(t => window.renderAt(t), f / FPS);
    const buf = await p.screenshot({ type: 'jpeg', quality: 95 });
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    done++; if (done % 60 === 0) { const s = (Date.now() - t0) / 1000; console.log(`${done}/${N} klatek, ${s.toFixed(0)} s, ok. ${((N - done) * s / done / 60).toFixed(1)} min do końca`); }
  }
  ff.stdin.end(); if (await closed !== 0) { console.error('ffmpeg: błąd w segmencie', w); process.exit(1); } await br.close();
}));
fs.writeFileSync(path.join(OUT, 'list.txt'), [...Array(WK)].map((_, w) => w).filter(w => w * per < N).map(w => `file 'seg_${w}.mp4'`).join('\n'));
const run = a => execFileSync(ffmpeg, a, { cwd: OUT, stdio: 'inherit' });
run(['-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', 'list.txt', '-c', 'copy', 'video.mp4']);
console.log('Kodowanie końcowe (2 przebiegi, z dźwiękiem)...');
run(['-y', '-loglevel', 'error', '-i', 'video.mp4', '-c:v', 'libx264', '-preset', 'slow', '-b:v', '10M', '-maxrate', '14M', '-bufsize', '20M', '-pass', '1', '-an', '-f', 'mp4', process.platform === 'win32' ? 'NUL' : '/dev/null']);
run(['-y', '-loglevel', 'error', '-i', 'video.mp4', '-i', path.join(D, 'audio.m4a'), '-map', '0:v', '-map', '1:a', '-c:v', 'libx264', '-preset', 'slow', '-b:v', '10M', '-maxrate', '14M', '-bufsize', '20M', '-pass', '2', '-pix_fmt', 'yuv420p', '-c:a', 'copy', '-t', String(info.dur), '-movflags', '+faststart', path.join(D, NAME)]);
console.log(`GOTOWE: ${NAME} (${(fs.statSync(path.join(D, NAME)).size / 1e6).toFixed(0)} MB) w ${((Date.now() - t0) / 60000).toFixed(1)} min. Napisz Claude'owi, że skończone.`);
