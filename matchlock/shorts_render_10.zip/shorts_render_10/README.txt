How It Works #10 - zamek lontowy (Matchlock)
1. Kliknij start.bat (render na GPU, kilka minut). Na koncu pojawi sie matchlock_short_9x16.mp4.
2. Kliknij finish.bat - wysyla MP4 do Gromiasty/shorts-media (folder matchlock/).
