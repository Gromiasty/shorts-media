Render How It Works #09 na GPU
1. Uruchom start.bat (dwuklik).
2. Otworza sie okna Chrome - nie zamykaj ich, mozna je zminimalizowac.
3. Na koncu w tym folderze pojawi sie egyptian_sled_short_9x16.mp4.
Wymagane: Node.js i Google Chrome.
