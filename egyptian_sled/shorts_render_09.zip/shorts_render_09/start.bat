@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Brak Node.js - zainstaluj z https://nodejs.org i uruchom ponownie. & pause & exit /b 1)
if not exist node_modules\playwright-core call npm install --no-audit --no-fund
node render_local.mjs 4
pause
